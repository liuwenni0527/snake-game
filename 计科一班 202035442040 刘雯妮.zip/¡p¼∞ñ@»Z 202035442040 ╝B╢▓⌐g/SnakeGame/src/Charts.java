import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import javax.swing.*;

public class Charts extends JFrame{
	UserInfo[] userList;

	Charts(JFrame mainFrame){
		this.setSize(500,250);
		this.setLocationRelativeTo(null);
		this.setTitle("排行榜");
		this.setResizable(false);
		this.setLayout(null);
		this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		this.addWindowListener(new WindowAdapter(){
			public void windowClosed(WindowEvent e){
				mainFrame.setVisible(true);
			}
		});
		
		loadUserInfo();
		
		selectionSort(userList,true);
		String[] score_list=new String[userList.length+1];
		score_list[0]=String.format("%-15s%-15s%-15s", "排名","用戶","分數");
		for(int i=0;i<userList.length;i++) {
			score_list[i+1]=String.format("%-15s%-15s%-15s", i+1,userList[i].account,userList[i].maxscore);
		}
		JList score_charts=new JList(score_list);
		JScrollPane score_scroll= new JScrollPane(score_charts);
		score_scroll.setBounds(10,5,460,200);
		score_scroll.setBorder(BorderFactory.createTitledBorder("分數排行"));
		this.add(score_scroll);
		this.setVisible(true);
	}
	

	private void selectionSort(UserInfo[] userList,boolean key) {
		if(key) {
			for(int i=0;i<userList.length-1;i++) {
				int max=i;
				for(int j=i+1;j<userList.length;j++) {
					if(userList[j].maxscore>userList[max].maxscore) {
						max=j;
					}
				}
				swapUserInfo(userList,i,max);
			}
		}
	}
	
	private void swapUserInfo(UserInfo[] userList,int i,int j) {
		UserInfo temp=userList[i];
		userList[i]=userList[j];
		userList[j]=temp;
	}
	
	private void loadUserInfo() {
		Users users=new Users();
		userList=new UserInfo[users.getUserCount()];
		for(int i=0;i<userList.length;i++) {
			userList[i]=new UserInfo(users.getAccount(i+1),users.getMaxScore(i+1));
		}
	}
	
	class UserInfo{
		String account;
		int maxscore;
		UserInfo(String account,int maxscore){
			this.account=account;
			this.maxscore=maxscore;
		}
	}
}
