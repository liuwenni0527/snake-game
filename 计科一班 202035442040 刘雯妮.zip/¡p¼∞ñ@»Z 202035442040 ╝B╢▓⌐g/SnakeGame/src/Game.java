import java.awt.*;
import java.awt.event.*;
import java.util.Random;
import javax.swing.*;

public class Game extends JFrame implements ActionListener,KeyListener{
	enum Direction{up,down,left,right};//枚舉方向類
	private int ID;	
	private Food food;
	private Snake snake;
	private JPanel gamePanel;
	private int score=0;
	private Timer timer;
	private final int speedSlow=100;
	private final int speedFast=30;
	private final int gamePanelWidth=875;
	private final int gamePanelHeight=700;
	private boolean isGameStart=false;
	private boolean isGameRunning=false;
	private boolean isGameFailed=false;
	private ImageIcon fail;
	private ImageIcon pause;
	private JLabel label_maxscore;
	private JLabel label_score;
	private JLabel label_len;
	private JLabel label_account;
	private Users users;
	
	Game(JFrame mainFrame,int id){
		ID=id;
		this.setSize(gamePanelWidth+180,gamePanelHeight+50);
		this.setLayout(null);
		this.setResizable(false);
		this.setLocationRelativeTo(null);
		this.setTitle("Snake Game");
		this.setVisible(true);
		this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		this.addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent e) {
				timer.stop();
				mainFrame.setVisible(true);
			}
		});
		
		gamePanel=new GamePanel();
		gamePanel.setBounds(0,0,gamePanelWidth,gamePanelHeight);
		gamePanel.setBackground(new Color(230,230,230));
		this.add(gamePanel);
		
		
		JPanel panel_account=new JPanel();
		panel_account.setBounds(gamePanelWidth+10,0,150,80);
		panel_account.setBorder(BorderFactory.createTitledBorder("Account"));
		panel_account.setLayout(new BoxLayout(panel_account,BoxLayout.Y_AXIS));
		this.add(panel_account);
		JLabel label_id=new JLabel("ID:"+ID);
		panel_account.add(label_id);
		label_account=new JLabel("用戶名:");
		panel_account.add(label_account);
		label_maxscore=new JLabel("最高分數:");
		panel_account.add(label_maxscore);
		
		
		JPanel panel_game=new JPanel();
		panel_game.setBounds(gamePanelWidth+10,100,150,60);
		panel_game.setBorder(BorderFactory.createTitledBorder("Game"));
		panel_game.setLayout(new BoxLayout(panel_game,BoxLayout.Y_AXIS));
		this.add(panel_game);
		label_score=new JLabel("當前分數:0");
		panel_game.add(label_score);
		label_len=new JLabel("蛇身長度:3");
		panel_game.add(label_len);

		
		JButton btn_begin=new JButton("開始遊戲");
		btn_begin.setBounds(gamePanelWidth+10,250,150,50);
		btn_begin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(isGameStart && !isGameFailed && !isGameRunning) {	//判斷遊戲是否正在進行
					gamePanel.requestFocus();
					timer.start();
					isGameRunning=true;
				}else {	
					gamePanel.requestFocus();
					snake.reborn();
					score=0;
					timer.start();
					isGameStart=true;
					isGameRunning=true;
					isGameFailed=false;
				}
			}
		});
		this.add(btn_begin);
		
		ImageIcon helpicon=new ImageIcon("pic/help.png");
		JLabel help=new JLabel();
		help.setBounds(gamePanelWidth+10,350,150,250);
		help.setIcon(helpicon);
		this.add(help);
		
		init();	//刷新遊戲
	}
	
	private void init() {
		snake=new Snake();
		food=new Food();
		score=0;
		users=new Users();
		showAccountInformation();
		gamePanel.setFocusable(true);
		gamePanel.addKeyListener(this);
		timer=new Timer(speedSlow,this);
		fail=new ImageIcon("pic/fail.png");
		pause=new ImageIcon("pic/pause.png");
	}
	
	private void showAccountInformation() {
		label_account.setText("帳號:"+users.getAccount(ID));
		label_maxscore.setText("最高紀錄:"+users.getMaxScore(ID));
	}
	
	private void failed() {
		users.modifyMaxScore(ID, users.getMaxScore(ID)>score?users.getMaxScore(ID):score);
		showAccountInformation();
		isGameStart=false;
		isGameRunning=false;
		isGameFailed=true;
	}
	
	private class GamePanel extends JPanel{
		public void paint(Graphics g) {
			super.paint(g);
			
			g.setColor(new Color(250,250,250));
			for(int i=0;i<gamePanelWidth;i+=25)
				g.drawLine(i, 0, i, gamePanelHeight);
			for(int i=0;i<gamePanelHeight;i+=25)
				g.drawLine(0, i, gamePanelWidth, i);
			
			food.food.paintIcon(this, g, food.x-(food.food.getIconWidth()/2-25/2), food.y-(food.food.getIconHeight()/2-25/2));
			
			for(int i=1;i<snake.len;i++) {
				snake.body.paintIcon(this, g, snake.x[i], snake.y[i]);
			}

			switch(snake.direction) {
			case up:snake.up.paintIcon(this, g, snake.x[0]-(snake.up.getIconWidth()/2-25/2),snake.y[0]-(snake.up.getIconHeight()-25)-3);
			break;
			case down:snake.down.paintIcon(this, g, snake.x[0]-(snake.down.getIconWidth()/2-25/2),snake.y[0]+3);
			break;
			case left:snake.left.paintIcon(this, g, snake.x[0]-(snake.left.getIconWidth()-25)-3,snake.y[0]-(snake.left.getIconHeight()/2-25/2));
			break;
			case right:snake.right.paintIcon(this, g, snake.x[0]+3,snake.y[0]-(snake.right.getIconHeight()/2-25/2));
			break;
			}
			
			if(isGameFailed) {
				fail.paintIcon(this, g, 0, 150);
			}
			
			if(isGameStart && !isGameRunning) {
				pause.paintIcon(this, g, 0, 150);
			}
		}
	}
	
	private class Snake{
		int[] x=new int [gamePanelWidth*gamePanelHeight];
		int[] y=new int [gamePanelWidth*gamePanelHeight];
		int len;
		Direction direction;
		ImageIcon up=new ImageIcon("skin/skin1/up.png");
		ImageIcon down = new ImageIcon("skin/skin1/down.png");
	    ImageIcon left = new ImageIcon("skin/skin1/left.png");
	    ImageIcon right = new ImageIcon("skin/skin1/right.png");
	    ImageIcon body = new ImageIcon("skin/skin1/body.png");
	    
	    Snake(){
	        x[2]=0;x[1]=25;x[0]=50;
	        y[2]=y[1]=y[0]=25;
	        len=3;
	        direction=direction.right;
	    }
	    
	    public void reborn() {
	    	x[2]=0;x[1]=25;x[0]=50;
	        y[2]=y[1]=y[0]=25;
	        len=3;
	        direction=direction.right;
	    }	    
	}
	
	private class Food{
		Random random=new Random();
		ImageIcon food=new ImageIcon("skin/skin1/food.png");
		int x;
		int y;
		
		Food(){
			reborn();
		}
		
		public void reborn() {
			x=random.nextInt(875/25)*25;
			y=random.nextInt(700/25)*25;
			
			for(int k=0;k<5;k++) {
				boolean flag=true;
				for(int i=0;i<snake.len;i++) {
					if(x==snake.x[i] && y==snake.y[i]) {
						x=random.nextInt(875/25)*25;
						y=random.nextInt(700/25)*25;
						flag=false;
						break;
					}
				}
				if(flag)
					break;
			}
		}

	}


	@Override
	public void actionPerformed(ActionEvent e) {
		
		for(int i=snake.len;i>0;i--) {
			snake.x[i]=snake.x[i-1];
			snake.y[i]=snake.y[i-1];
		}
		
		switch(snake.direction) {
		case up:snake.y[0]-=25;
		break;
		case down:snake.y[0]+=25;
		break;
		case left:snake.x[0]-=25;
		break;
		case right:snake.x[0]+=25;
		break;
		}
		
		if(snake.x[0]==food.x && snake.y[0]==food.y) {
			score+=2;
			snake.len++;
			food.reborn();
		}
		
		for(int i=1;i<snake.len;i++) {
			if(snake.x[0]==snake.x[i] && snake.y[0]==snake.y[i]) {
				failed();
				timer.stop();
			}
		}
		
		if(snake.x[0]<0 || snake.x[0]>gamePanelWidth-25 || snake.y[0]<0 || snake.y[0]>gamePanelHeight-25) {
			failed();
			timer.stop();
		}
		
		label_score.setText("當前分數:"+score);
		label_len.setText("蛇身長度:"+snake.len);
		
		gamePanel.repaint();
	}

	@Override
	public void keyPressed(KeyEvent arg0) {
		int keyCode = arg0.getKeyCode();
		
		if(isGameRunning) {
			switch(keyCode) {//上下左右控制方向
			case KeyEvent.VK_UP:snake.direction=(snake.direction==Direction.down)?Direction.down:Direction.up;
			break;
			case KeyEvent.VK_DOWN:snake.direction=(snake.direction==Direction.up)?Direction.up:Direction.down;
			break;
			case KeyEvent.VK_LEFT:snake.direction=(snake.direction==Direction.right)?Direction.right:Direction.left;
			break;
			case KeyEvent.VK_RIGHT:snake.direction=(snake.direction==Direction.left)?Direction.left:Direction.right;
			break;
			}
			
			if(keyCode==KeyEvent.VK_SHIFT)
				timer.setDelay(speedFast);
		}

	}

	@Override
	public void keyReleased(KeyEvent arg0) {
		int keyCode = arg0.getKeyCode();
		
		if(keyCode==KeyEvent.VK_SHIFT)
			timer.setDelay(speedSlow);

		if(isGameStart) {
			if(keyCode==KeyEvent.VK_SPACE){
				if(timer.isRunning()) {
					repaint();
					timer.stop();
					isGameRunning=false;
				}
				else {
					timer.start();
					isGameRunning=true;
				}
					
			}
		}
		
		if(keyCode==KeyEvent.VK_R) {
			gamePanel.requestFocus();
			snake.reborn();
			score=0;
			timer.start();
			isGameStart=true;
			isGameRunning=true;
			isGameFailed=false;
		}
	}

	@Override
	public void keyTyped(KeyEvent arg0) {
	}
}
