import java.awt.event.*;
import javax.swing.*;

public class Main {
	private static int id=0;
	private static JLabel label_account;
	
	public static void main(String[] args) {
		JFrame frame=new JFrame();
		frame.setSize(400, 300);
		frame.setLocationRelativeTo(null);
		frame.setTitle("貪吃蛇");
		frame.setResizable(false);
		frame.setLayout(null);
		
		label_account=new JLabel("管理員:liuwenni");
		label_account.setBounds(5,5,400,30);
		frame.add(label_account);
		
		ImageIcon logo1=new ImageIcon("pic/welcome.png");
		JLabel logo=new JLabel();
		logo.setIcon(logo1);
		logo.setBounds(-100,-10,600,280);
		frame.add(logo);

		JButton btn_game=new JButton("開始遊戲");
		btn_game.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(id==0) {
					if(JOptionPane.showConfirmDialog(frame, "請用戶先登錄或註冊", "Snake",JOptionPane.YES_NO_OPTION)==JOptionPane.YES_OPTION) {
						frame.setVisible(false);
						new Account(frame);
					}
				}else {
					frame.setVisible(false);
					new Game(frame,id);
				}
			}
		});
		btn_game.setBounds(frame.getWidth()/2-75,130,150,30);
		frame.add(btn_game);
		
		JButton btn_account=new JButton("帳號管理");
		btn_account.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frame.setVisible(false);
				new Account(frame);
			}
		});
		btn_account.setBounds(frame.getWidth()/2-75,170,150,30);
		frame.add(btn_account);
		
		JButton btn_charts=new JButton("排行榜");
		btn_charts.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frame.setVisible(false);
				new Charts(frame);
			}
		});
		btn_charts.setBounds(frame.getWidth()/2-75,210,150,30);
		frame.add(btn_charts);
		
		frame.setVisible(true);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	
	public static void login(int i) {
		id=i;
		label_account.setText("帳號:"+new Users().getAccount(i));
	}

}
